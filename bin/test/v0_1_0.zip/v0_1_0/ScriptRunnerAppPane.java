package iu.ScriptRunnerApp.v0_1_0;

//-*- mode:java; encoding:utf8n; coding:utf-8 -*-
// vim:set fileencoding=utf-8:
//http://terai.xrea.jp/Swing/SwingWorker.html


//import iu.ScriptRunnerApp.v0_1_0.ButtonSystem.CancelButton.CancelButton;
import iu.ScriptRunnerApp.v0_1_0.ButtonSystem.RunButton.RunButton;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.*;
import java.util.List;

public class ScriptRunnerAppPane extends JPanel {

    private final AnimatedLabel animatedLabel = new AnimatedLabel();
    private static String bashScriptFilePath = "./settings/ScriptRunnerApp/sample_script.sh";
    private static String logFilePath = "settings/ScriptRunnerApp/sample_script.txt";
    private static String propFilePath = "settings/ScriptRunnerApp/settings.prop";

    private static final JFrame mainFrame = new JFrame("ScriptRunnerApp");
    private final JTextArea textArea = new JTextArea();
    private final JPanel progressBarPanel = new JPanel(new BorderLayout());
    private final JButton runButton = new RunButton();

    //private final JButton cancelButton = new CancelButton();

    private JButton editPropButton;

    private SwingWorker<String, String> worker;

    private static Process currentProcess;

    public ScriptRunnerAppPane() {
        super(new BorderLayout(5, 5));

        animatedLabel.addMouseListener(new TextAreaOpener());

        textArea.setEditable(false);

        Box hbox = Box.createHorizontalBox();
        hbox.add(animatedLabel);
        hbox.add(Box.createHorizontalGlue());
        hbox.add(runButton);
        hbox.add(Box.createHorizontalStrut(2));
        //hbox.add(cancelButton);
        hbox.add(Box.createHorizontalStrut(2));

        editPropButton = new EditPropButton(propFilePath, mainFrame);
        hbox.add(editPropButton);


        add(new JScrollPane(textArea));

        add(hbox, BorderLayout.NORTH);
        add(progressBarPanel, BorderLayout.SOUTH);
        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setPreferredSize(new Dimension(320, 180));
    }


    public static void createAndShowGUI() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        //mainFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        mainFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        Box hbox = Box.createHorizontalBox();
        hbox.add(new ScriptRunnerAppPane());

        mainFrame.getContentPane().add(hbox);

        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                createAndShowGUI();
            }
        });
    }

    private static JProgressBar progressBar = new JProgressBar(0, 100);



    /**
     * @param str
     */
    private void appendLineToTextArea(String str) {
        textArea.append(str + "\n");
        textArea.setCaretPosition(textArea.getDocument().getLength());
    }

    private class TextAreaOpener implements MouseListener {

        @Override
        public void mouseClicked(MouseEvent e) {
            JOptionPane.showInputDialog("OK");

        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }
    }

}


