package iu.ScriptRunnerApp.v0_1_0.ButtonSystem.CancelButton;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class CancelButton extends JButton {

    public CancelButton() {
        super("cancel");
    }

    class CancelAction extends AbstractAction {

        public CancelAction() {
            super("cancel");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (worker != null && !worker.isDone()) {
                worker.cancel(true);
            }
            worker = null;

            if (currentProcess != null) {
                currentProcess.destroy();
            }

        }
    }

}
