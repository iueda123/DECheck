package iu.ScriptRunnerApp.v0_1_0.ButtonSystem;

public interface Mediator {

    public abstract void createMembers();
    // MemberをConstructする。

    public abstract void reportFromAMember_Example(Member member);
    // Memberからの報告を受けての挙動の例

    public abstract void requestFromAMember_Example(Member member);
    // Memberからの要求を受けての挙動の例

}