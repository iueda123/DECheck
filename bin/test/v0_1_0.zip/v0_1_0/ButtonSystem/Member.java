package iu.ScriptRunnerApp.v0_1_0.ButtonSystem;

public interface Member {

    public abstract void setMediator(Mediator mediator);
    //　Mediator との紐づけのためのメソッド。
    // Mediator継承クラスにおけるcreateMembers()内で使う。

    public abstract void initialize();
    // Mediator との紐づけ後に呼び出される初期化メソッド。
    // Mediator継承クラスにおけるcreateMembers()内で使う。


    public abstract void orderFromMediator();
    // その他Memberで共通に持たせたいMediatorからの指示を受けるためのメソッド

}